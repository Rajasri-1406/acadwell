import React from 'react';
import "../../../css/dashboards/student/index.css";

const StudentSettings = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>Settings</h1>
      <p>Privacy & notification settings.</p>
    </div>
  );
};

export default StudentSettings;
